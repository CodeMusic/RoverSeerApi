#!/usr/bin/env python3
"""
Test script for RoverCub button functionality
"""

import sys
import os
import time

# Add custom drivers
custom_drivers_path = os.path.expanduser("~/custom_drivers")
if os.path.exists(custom_drivers_path):
    sys.path.insert(0, custom_drivers_path)
    try:
        from rainbow_driver import RainbowDriver, BuzzerManager
        print(f"✅ Loaded Rainbow HAT drivers from {custom_drivers_path}")
    except ImportError as e:
        print(f"❌ Failed to import Rainbow HAT drivers: {e}")
        sys.exit(1)
else:
    print(f"❌ custom_drivers not found at {custom_drivers_path}")
    sys.exit(1)

def test_buttons():
    """Test Rainbow HAT buttons"""
    print("\n🔘 Testing Rainbow HAT Buttons")
    print("==============================")
    print("Press buttons to test:")
    print("  A = Left (should beep low)")
    print("  B = Select (should beep medium)")
    print("  C = Right (should beep high)")
    print("  Ctrl+C to exit\n")
    
    try:
        # Initialize Rainbow HAT
        rainbow = RainbowDriver(use_experimental_strip=False)
        buzzer = BuzzerManager()
        
        # Button press counters
        button_presses = {'A': 0, 'B': 0, 'C': 0}
        
        # Set up button handlers
        def button_a_handler():
            button_presses['A'] += 1
            print(f"[A] Button A pressed! (count: {button_presses['A']})")
            buzzer.play_tone_immediate(392, 0.1)  # G4
            rainbow.display_text("LEFT")
            
        def button_b_handler():
            button_presses['B'] += 1
            print(f"[B] Button B pressed! (count: {button_presses['B']})")
            buzzer.play_tone_immediate(523, 0.1)  # C5
            rainbow.display_text("SEL")
            
        def button_c_handler():
            button_presses['C'] += 1
            print(f"[C] Button C pressed! (count: {button_presses['C']})")
            buzzer.play_tone_immediate(659, 0.1)  # E5
            rainbow.display_text("RGHT")
        
        # Assign handlers
        rainbow.buttons['A'].when_pressed = button_a_handler
        rainbow.buttons['B'].when_pressed = button_b_handler
        rainbow.buttons['C'].when_pressed = button_c_handler
        
        # Initial display
        rainbow.display_text("TEST")
        
        # Keep running
        while True:
            time.sleep(0.1)
            
    except KeyboardInterrupt:
        print("\n\n📊 Button press summary:")
        for button, count in button_presses.items():
            print(f"  Button {button}: {count} presses")
        
        # Cleanup
        rainbow.clear_display()
        rainbow.shutdown()
        buzzer.shutdown()
        print("\n✅ Test complete!")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    test_buttons() 