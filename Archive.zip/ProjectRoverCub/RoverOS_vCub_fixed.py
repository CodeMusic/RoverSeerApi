#!/usr/bin/env python3
"""
RoverCub Fixed - With better error handling and debugging
"""

import os
import sys
import time
import subprocess
import argparse
import requests
import json
import threading
import queue
import random
from evdev import InputDevice, categorize, ecodes
import numpy as np

# Add custom drivers from home directory
custom_drivers_path = os.path.expanduser("~/custom_drivers")
if os.path.exists(custom_drivers_path):
    sys.path.insert(0, custom_drivers_path)
    try:
        from rainbow_driver import RainbowDriver, BuzzerManager
        print(f"[DRIVERS] Loaded Rainbow HAT drivers from {custom_drivers_path}")
    except ImportError as e:
        print(f"[ERROR] Failed to import Rainbow HAT drivers: {e}")
        RainbowDriver = None
        BuzzerManager = None
else:
    print(f"[ERROR] custom_drivers not found at {custom_drivers_path}")
    print("[WARNING] Running without Rainbow HAT support")
    RainbowDriver = None
    BuzzerManager = None

# API Configuration
ROVERSEER_API = "http://roverseer.local:5000"
ENDPOINTS = {
    "transcribe": f"{ROVERSEER_API}/api/transcribe",
    "llm": f"{ROVERSEER_API}/api/llm",
    "tts": f"{ROVERSEER_API}/api/tts",
    "models": f"{ROVERSEER_API}/models",
    "voices": f"{ROVERSEER_API}/api/voices"
}

# Global variables
current_model = None  # Current model from API
current_voice = None  # Current voice from API
available_models = []  # Models from API
available_voices = []  # Voices from API
model_select_mode = False
voice_select_mode = False
selected_index = 0
rainbow_driver = None
buzzer_manager = None

# Conversation History
conversation_history = []
MAX_HISTORY_LENGTH = 10

# Animation States
IDLE = 'idle'
LISTENING = 'listening'
PROCESSING = 'processing'
TALKING = 'talking'
HEARTBEAT = 'heartbeat'
SPECTRUM = 'spectrum'
MODEL_SELECT = 'model_select'
VOICE_SELECT = 'voice_select'

# LED Animation configuration
led_animation_thread = None
led_animation_running = False
current_animation_state = IDLE
animation_tokens = None

# Config file path
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'rovercub_config.json')

def load_config():
    """Load configuration from file"""
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                print("[CONFIG] Loaded configuration")
                return config
    except Exception as e:
        print(f"[WARNING] Failed to load config: {e}")
    return {}

def save_config():
    """Save configuration to file"""
    try:
        config = {
            'current_model': current_model['name'] if current_model else None,
            'current_voice': current_voice
        }
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
        print("[CONFIG] Saved configuration")
    except Exception as e:
        print(f"[WARNING] Failed to save config: {e}")

def display_model_info():
    """Display current model info on display"""
    if rainbow_driver:
        if available_models and 0 <= selected_index < len(available_models):
            model = available_models[selected_index]
            # Extract short name for display
            model_name = model['name']
            # Take first 4 chars or until ':'
            short_name = model_name.split(':')[0][:4].upper()
            rainbow_driver.display_text(short_name)
        else:
            rainbow_driver.display_text("????")

def display_voice_info():
    """Display current voice info on display"""
    if rainbow_driver:
        if available_voices and 0 <= selected_index < len(available_voices):
            voice = available_voices[selected_index]
            # Take first 4 chars of voice name
            short_name = voice[:4].upper()
            rainbow_driver.display_text(short_name)
        else:
            rainbow_driver.display_text("????")

def transcribe_audio(audio_file):
    """Send audio file to transcribe endpoint"""
    try:
        print(f"[TRANSCRIBE] Sending {audio_file} to API...")
        with open(audio_file, 'rb') as f:
            files = {'file': f}
            response = requests.post(ENDPOINTS['transcribe'], files=files, timeout=30)
            response.raise_for_status()
            result = response.json()
            print(f"[TRANSCRIBE] Response: {result}")
            return result.get('text', '')
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Transcription request failed: {e}")
        return None
    except Exception as e:
        print(f"[ERROR] Transcription failed: {e}")
        return None

def get_llm_response(text):
    """Get response from LLM endpoint with current model"""
    try:
        print(f"[LLM] Sending request with model: {current_model['name'] if current_model else 'default'}")
        
        # Build messages including history
        messages = conversation_history.copy()
        messages.append({"role": "user", "content": text})
        
        payload = {
            'messages': messages,
            'model': current_model['name'] if current_model else 'tinydolphin:1.1b'
        }
        
        print(f"[LLM] Payload: {json.dumps(payload, indent=2)}")
        
        response = requests.post(ENDPOINTS['llm'], json=payload, timeout=60)
        response.raise_for_status()
        
        result = response.json()
        print(f"[LLM] Response received: {len(result.get('response', ''))} chars")
        
        ai_response = result.get('response', '')
        
        if ai_response:
            # Add to history
            add_to_history("user", text)
            add_to_history("assistant", ai_response)
        
        return ai_response
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] LLM request failed: {e}")
        if hasattr(e, 'response') and e.response:
            print(f"[ERROR] Response: {e.response.text}")
        return None
    except Exception as e:
        print(f"[ERROR] LLM failed: {e}")
        return None

def get_tts_audio(text):
    """Get TTS audio from endpoint"""
    try:
        print(f"[TTS] Generating audio with voice: {current_voice}")
        
        payload = {
            'text': text,
            'voice': current_voice or 'en_US-GlaDOS'
        }
        
        response = requests.post(ENDPOINTS['tts'], json=payload, timeout=30)
        response.raise_for_status()
        
        # Check if we got audio data
        if len(response.content) < 1000:
            print(f"[WARNING] TTS response too small: {len(response.content)} bytes")
            print(f"[WARNING] Response text: {response.text[:200]}")
            return None
        
        # Save the audio file
        tts_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tts_response.wav')
        with open(tts_file, 'wb') as f:
            f.write(response.content)
        
        print(f"[TTS] Audio saved: {len(response.content)} bytes")
        return tts_file
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] TTS request failed: {e}")
        if hasattr(e, 'response') and e.response:
            print(f"[ERROR] Response: {e.response.text}")
        return None
    except Exception as e:
        print(f"[ERROR] TTS failed: {e}")
        return None

def play_audio(file_path):
    """Play audio file using aplay"""
    print(f"[PLAY] Playing audio: {file_path}")
    try:
        # Check file size
        size = os.path.getsize(file_path)
        print(f"[PLAY] File size: {size} bytes")
        
        # Use aplay for WAV files
        play_cmd = ['aplay', file_path]
        result = subprocess.run(play_cmd, capture_output=True, text=True)
        
        if result.returncode != 0:
            print(f"[ERROR] aplay failed: {result.stderr}")
            # Try mpg123 as fallback
            play_cmd = ['mpg123', '-q', file_path]
            subprocess.run(play_cmd)
        
        # Clean up the file
        try:
            os.remove(file_path)
        except Exception as e:
            print(f"[WARNING] Could not remove temporary file: {e}")
    except Exception as e:
        print(f"[ERROR] Audio playback failed: {e}")

def fetch_models():
    """Fetch available models from API"""
    global available_models, current_model
    try:
        print("[MODELS] Fetching from API...")
        response = requests.get(ENDPOINTS['models'], timeout=10)
        response.raise_for_status()
        data = response.json()
        available_models = data.get('models', [])
        
        print(f"[MODELS] Received {len(available_models)} models")
        
        # Load saved preference or use first model
        config = load_config()
        saved_model = config.get('current_model')
        
        if saved_model:
            for model in available_models:
                if model['name'] == saved_model:
                    current_model = model
                    break
        
        if not current_model and available_models:
            current_model = available_models[0]
            
        if current_model:
            print(f"[MODELS] Current model: {current_model['name']}")
        
        return True
    except Exception as e:
        print(f"[ERROR] Failed to fetch models: {e}")
        # Add a dummy model for testing
        available_models = [{'name': 'tinydolphin:1.1b', 'parameters': '1.1B'}]
        current_model = available_models[0]
        return False

def fetch_voices():
    """Fetch available voices from API"""
    global available_voices, current_voice
    try:
        print("[VOICES] Fetching from API...")
        response = requests.get(ENDPOINTS['voices'], timeout=10)
        response.raise_for_status()
        data = response.json()
        available_voices = data.get('voices', [])
        
        print(f"[VOICES] Received {len(available_voices)} voices")
        
        # Load saved preference or use first voice
        config = load_config()
        saved_voice = config.get('current_voice')
        
        if saved_voice and saved_voice in available_voices:
            current_voice = saved_voice
        elif available_voices:
            current_voice = available_voices[0]
            
        if current_voice:
            print(f"[VOICES] Current voice: {current_voice}")
        
        return True
    except Exception as e:
        print(f"[ERROR] Failed to fetch voices: {e}")
        # Use RoverSeer default voices if API fails
        available_voices = ["en_US-GlaDOS", "en_GB-jarvis", "en_US-amy", "en_GB-northern_english"]
        current_voice = "en_US-GlaDOS"
        return False

def add_to_history(role, content):
    """Add a message to the conversation history"""
    global conversation_history
    conversation_history.append({"role": role, "content": content})
    if len(conversation_history) > MAX_HISTORY_LENGTH * 2:
        conversation_history = conversation_history[-MAX_HISTORY_LENGTH * 2:]
    print(f"[HISTORY] Added {role} message, history length: {len(conversation_history)}")

# Copy the rest of the original functions here... 