#!/usr/bin/env python3
"""
RoverCub with Personality System - Voice-Controlled AI Assistant

Features:
- Personality selection (sets voice and system message)
- Separate model selection for exploration
- Push-to-talk functionality
- LED animations matching RoverSeer
- Rainbow HAT support
"""

import os
import sys
import time
import subprocess
import argparse
import requests
import json
import threading
import queue
import random
from evdev import InputDevice, categorize, ecodes
import numpy as np

# Add custom drivers from home directory
custom_drivers_path = os.path.expanduser("~/custom_drivers")
if os.path.exists(custom_drivers_path):
    sys.path.insert(0, custom_drivers_path)
    try:
        from rainbow_driver import RainbowDriver, BuzzerManager
        print(f"[DRIVERS] Loaded Rainbow HAT drivers from {custom_drivers_path}")
    except ImportError as e:
        print(f"[ERROR] Failed to import Rainbow HAT drivers: {e}")
        RainbowDriver = None
        BuzzerManager = None
else:
    print(f"[ERROR] custom_drivers not found at {custom_drivers_path}")
    print("[WARNING] Running without Rainbow HAT support")
    RainbowDriver = None
    BuzzerManager = None

# API Configuration
ROVERSEER_API = "http://roverseer.local:5000"
ENDPOINTS = {
    "transcribe": f"{ROVERSEER_API}/api/transcribe",
    "llm": f"{ROVERSEER_API}/api/llm",
    "tts": f"{ROVERSEER_API}/api/tts",
    "models": f"{ROVERSEER_API}/models",
    "personalities": f"{ROVERSEER_API}/personalities",
    "personality_switch": f"{ROVERSEER_API}/personalities/switch",
    "personality_current": f"{ROVERSEER_API}/personalities/current"
}

# Global variables
current_model = None  # Current model from API
current_personality = None  # Current personality
available_models = []  # Models from API
available_personalities = []  # Personalities from API
model_select_mode = False
personality_select_mode = False
selected_index = 0
rainbow_driver = None
buzzer_manager = None

# Conversation History
conversation_history = []
MAX_HISTORY_LENGTH = 10

# Animation States
IDLE = 'idle'
LISTENING = 'listening'
PROCESSING = 'processing'
TALKING = 'talking'
HEARTBEAT = 'heartbeat'
SPECTRUM = 'spectrum'
MODEL_SELECT = 'model_select'
PERSONALITY_SELECT = 'personality_select'

# LED Animation configuration
led_animation_thread = None
led_animation_running = False
current_animation_state = IDLE
animation_tokens = None

# Config file path
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'rovercub_config.json')

def load_config():
    """Load configuration from file"""
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                print("[CONFIG] Loaded configuration")
                return config
    except Exception as e:
        print(f"[WARNING] Failed to load config: {e}")
    return {}

def save_config():
    """Save configuration to file"""
    try:
        config = {
            'current_model': current_model['name'] if current_model else None,
            'current_personality': current_personality['name'] if current_personality else None
        }
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
        print("[CONFIG] Saved configuration")
    except Exception as e:
        print(f"[WARNING] Failed to save config: {e}")

def fetch_models():
    """Fetch available models from API"""
    global available_models, current_model
    try:
        print("[MODELS] Fetching from API...")
        response = requests.get(ENDPOINTS['models'], timeout=10)
        response.raise_for_status()
        data = response.json()
        available_models = data.get('models', [])
        
        print(f"[MODELS] Received {len(available_models)} models")
        
        # Load saved preference or use first model
        config = load_config()
        saved_model = config.get('current_model')
        
        if saved_model:
            for model in available_models:
                if model['name'] == saved_model:
                    current_model = model
                    break
        
        if not current_model and available_models:
            current_model = available_models[0]
            
        if current_model:
            print(f"[MODELS] Current model: {current_model['name']}")
        
        return True
    except Exception as e:
        print(f"[ERROR] Failed to fetch models: {e}")
        return False

def fetch_personalities():
    """Fetch available personalities from API"""
    global available_personalities, current_personality
    try:
        print("[PERSONALITIES] Fetching from API...")
        response = requests.get(ENDPOINTS['personalities'], timeout=10)
        response.raise_for_status()
        data = response.json()
        available_personalities = data.get('personalities', [])
        
        print(f"[PERSONALITIES] Received {len(available_personalities)} personalities")
        
        # Load saved preference
        config = load_config()
        saved_personality = config.get('current_personality')
        
        if saved_personality:
            for p in available_personalities:
                if p['name'] == saved_personality:
                    current_personality = p
                    # Switch to this personality on the API side too
                    switch_personality_api(saved_personality)
                    break
        
        if not current_personality and available_personalities:
            current_personality = available_personalities[0]
            switch_personality_api(current_personality['name'])
            
        if current_personality:
            print(f"[PERSONALITIES] Current: {current_personality['name']} (voice: {current_personality['voice_id']})")
        
        return True
    except Exception as e:
        print(f"[ERROR] Failed to fetch personalities: {e}")
        # Create default personality
        available_personalities = [{
            'name': 'RoverSeer',
            'voice_id': 'en_US-GlaDOS',
            'description': 'Default assistant',
            'avatar_emoji': '🤖'
        }]
        current_personality = available_personalities[0]
        return False

def switch_personality_api(personality_name):
    """Tell the API to switch personalities"""
    try:
        response = requests.post(ENDPOINTS['personality_switch'], 
                               json={'personality': personality_name},
                               timeout=10)
        if response.ok:
            print(f"[API] Switched to personality: {personality_name}")
            return True
    except Exception as e:
        print(f"[ERROR] Failed to switch personality on API: {e}")
    return False

def add_to_history(role, content):
    """Add a message to the conversation history"""
    global conversation_history
    conversation_history.append({"role": role, "content": content})
    if len(conversation_history) > MAX_HISTORY_LENGTH * 2:
        conversation_history = conversation_history[-MAX_HISTORY_LENGTH * 2:]

def clear_conversation_history():
    """Clear the conversation history"""
    global conversation_history
    conversation_history = []
    print("[CONVERSATION] History cleared")

def transcribe_audio(audio_file):
    """Send audio file to transcribe endpoint"""
    try:
        print(f"[TRANSCRIBE] Sending {audio_file} to API...")
        with open(audio_file, 'rb') as f:
            files = {'file': f}
            response = requests.post(ENDPOINTS['transcribe'], files=files, timeout=30)
            response.raise_for_status()
            result = response.json()
            print(f"[TRANSCRIBE] Got: {result.get('text', '')[:50]}...")
            return result.get('text', '')
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Transcription request failed: {e}")
        return None
    except Exception as e:
        print(f"[ERROR] Transcription failed: {e}")
        return None

def get_llm_response(text):
    """Get response from LLM endpoint with current model and personality"""
    try:
        model_name = current_model['name'] if current_model else 'tinydolphin:1.1b'
        
        # Check if personality has model preference
        if current_personality and current_personality.get('model_preference'):
            # Check if preferred model is available
            preferred = current_personality['model_preference']
            if any(m['name'] == preferred for m in available_models):
                print(f"[LLM] Using personality's preferred model: {preferred}")
                model_name = preferred
        
        print(f"[LLM] Sending request with model: {model_name}")
        
        # Build messages including history
        messages = conversation_history.copy()
        messages.append({"role": "user", "content": text})
        
        payload = {
            'messages': messages,
            'model': model_name
        }
        
        response = requests.post(ENDPOINTS['llm'], json=payload, timeout=60)
        response.raise_for_status()
        
        result = response.json()
        ai_response = result.get('response', '')
        
        if ai_response:
            # Add to history
            add_to_history("user", text)
            add_to_history("assistant", ai_response)
        
        return ai_response
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] LLM request failed: {e}")
        return None
    except Exception as e:
        print(f"[ERROR] LLM failed: {e}")
        return None

def get_tts_audio(text):
    """Get TTS audio from endpoint using personality's voice"""
    try:
        voice = current_personality['voice_id'] if current_personality else 'en_US-GlaDOS'
        print(f"[TTS] Generating audio with voice: {voice}")
        
        payload = {
            'text': text,
            'voice': voice
        }
        
        response = requests.post(ENDPOINTS['tts'], json=payload, timeout=30)
        response.raise_for_status()
        
        # Save the audio file
        tts_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tts_response.wav')
        with open(tts_file, 'wb') as f:
            f.write(response.content)
        
        print(f"[TTS] Audio saved: {os.path.getsize(tts_file)} bytes")
        return tts_file
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] TTS request failed: {e}")
        return None
    except Exception as e:
        print(f"[ERROR] TTS failed: {e}")
        return None

def play_audio(file_path):
    """Play audio file using aplay"""
    print(f"[PLAY] Playing audio: {file_path}")
    try:
        # Use aplay for WAV files
        play_cmd = ['aplay', file_path]
        result = subprocess.run(play_cmd, capture_output=True, text=True)
        
        if result.returncode != 0:
            print(f"[ERROR] aplay failed: {result.stderr}")
        
        # Clean up the file
        try:
            os.remove(file_path)
        except Exception as e:
            print(f"[WARNING] Could not remove temporary file: {e}")
    except Exception as e:
        print(f"[ERROR] Audio playback failed: {e}")

def update_animation_state(state, tokens=None):
    """Update the current animation state"""
    global current_animation_state, animation_tokens
    current_animation_state = state
    animation_tokens = tokens
    
    # Update Rainbow HAT display based on state
    if rainbow_driver:
        if state == IDLE:
            rainbow_driver.clear_display()
            rainbow_driver.led_manager.show_progress('idle')
        elif state == LISTENING:
            rainbow_driver.display_text("HEAR")
            rainbow_driver.led_manager.show_progress('recording')
        elif state == HEARTBEAT:
            rainbow_driver.display_text("REC")
            rainbow_driver.led_manager.show_progress('recording')
        elif state == PROCESSING:
            rainbow_driver.display_text("THINK")
            rainbow_driver.led_manager.show_progress('llm')
        elif state == TALKING:
            rainbow_driver.display_text("TALK")
            rainbow_driver.led_manager.show_progress('playing')
        elif state == MODEL_SELECT:
            rainbow_driver.display_text("MDL")
        elif state == PERSONALITY_SELECT:
            rainbow_driver.display_text("PERS")

def led_animation_loop():
    """Main animation loop for LEDs"""
    global led_animation_running
    phase = 0.0
    
    while led_animation_running:
        try:
            if current_animation_state == IDLE:
                # Calm breathing pattern
                breathing_animation(phase)
            elif current_animation_state == LISTENING:
                # Spectrum animation
                spectrum_animation(phase)
            elif current_animation_state == HEARTBEAT:
                # Heartbeat animation
                heartbeat_animation(phase)
            elif current_animation_state == PROCESSING:
                # Matrix animation
                matrix_animation(phase)
            elif current_animation_state == TALKING and animation_tokens:
                # Token visualization
                visualize_tokens(animation_tokens, phase)
            elif current_animation_state in [MODEL_SELECT, PERSONALITY_SELECT]:
                # Selection mode animation
                selection_animation(phase)
            
            phase += 0.1
            time.sleep(0.01)
        except Exception as e:
            print(f"[LED] Animation error: {e}")
            time.sleep(0.1)

def breathing_animation(phase):
    """Create a calm breathing animation on Rainbow HAT LEDs"""
    if not rainbow_driver:
        return
    
    try:
        intensity = 0.3 + 0.7 * (0.5 + 0.5 * np.sin(phase))
        
        for i in range(7):  # Rainbow HAT has 7 LEDs
            wave = np.sin(phase + i * 0.5)
            if wave > 0.5:
                color = (0, int(64 * intensity), int(32 * intensity))  # Green-blue
            else:
                color = (0, int(32 * intensity), int(64 * intensity))  # Blue-green
            
            rainbow_driver.set_led(i, *color)
        rainbow_driver._apply_leds()
    except Exception as e:
        print(f"[LED] Breathing animation error: {e}")

def spectrum_animation(phase):
    """Create a spectrum animation"""
    if not rainbow_driver:
        return
    
    try:
        for i in range(7):
            pos_phase = i * 0.5 + phase
            r = int(64 * (0.5 + 0.5 * np.sin(pos_phase)))
            g = int(64 * (0.5 + 0.5 * np.sin(pos_phase + 2.094)))
            b = int(64 * (0.5 + 0.5 * np.sin(pos_phase + 4.189)))
            
            rainbow_driver.set_led(i, r, g, b)
        rainbow_driver._apply_leds()
    except Exception as e:
        print(f"[LED] Spectrum animation error: {e}")

def heartbeat_animation(phase):
    """Create a heartbeat animation"""
    if not rainbow_driver:
        return
    
    try:
        beat = np.sin(phase * 4) * 0.5 + 0.5
        intensity = 0.3 + 0.7 * beat
        
        for i in range(7):
            r = int(64 * intensity)
            g = int(16 * intensity)
            b = int(16 * intensity)
            rainbow_driver.set_led(i, r, g, b)
        rainbow_driver._apply_leds()
    except Exception as e:
        print(f"[LED] Heartbeat animation error: {e}")

def matrix_animation(phase):
    """Create a Matrix-style animation"""
    if not rainbow_driver:
        return
    
    try:
        for i in range(7):
            fall_phase = (i * 0.5 + phase) % (2 * np.pi)
            brightness = np.sin(fall_phase) * 0.5 + 0.5
            
            if np.random.random() < 0.1:
                brightness = 1.0
            
            g = int(64 * brightness)
            rainbow_driver.set_led(i, 0, g, 0)
        rainbow_driver._apply_leds()
    except Exception as e:
        print(f"[LED] Matrix animation error: {e}")

def selection_animation(phase):
    """Create a selection mode animation"""
    if not rainbow_driver:
        return
    
    try:
        # Highlight current selection with moving pattern
        for i in range(7):
            if i == selected_index % 7:
                # Selected position pulses
                intensity = 0.5 + 0.5 * np.sin(phase * 3)
                color = (int(64 * intensity), int(32 * intensity), 0)
            else:
                # Other positions are dim
                color = (8, 8, 8)
            
            rainbow_driver.set_led(i, *color)
        rainbow_driver._apply_leds()
    except Exception as e:
        print(f"[LED] Selection animation error: {e}")

def visualize_tokens(tokens, phase):
    """Visualize tokens on the LEDs"""
    if not rainbow_driver:
        return
    
    try:
        # Token colors (ROYGBIV palette)
        token_colors = [
            (64, 0, 0),     # Red
            (64, 32, 0),    # Orange
            (64, 64, 0),    # Yellow
            (0, 64, 0),     # Green
            (0, 32, 64),    # Blue
            (32, 0, 64),    # Indigo
            (64, 0, 32),    # Violet
        ]
        
        for i in range(7):
            if i < len(tokens):
                token = tokens[i]
                base_color = token_colors[token % len(token_colors)]
                pulse = 0.1 * np.sin(phase + token * 0.5)
                color = tuple(int(c * (0.8 + pulse)) for c in base_color)
                rainbow_driver.set_led(i, *color)
            else:
                rainbow_driver.set_led(i, 0, 0, 0)
        rainbow_driver._apply_leds()
    except Exception as e:
        print(f"[LED] Token visualization error: {e}")

def display_model_info():
    """Display current model info on display"""
    if rainbow_driver:
        if available_models and 0 <= selected_index < len(available_models):
            model = available_models[selected_index]
            # Extract short name for display
            model_name = model['name']
            # Take first 4 chars or until ':'
            short_name = model_name.split(':')[0][:4].upper()
            rainbow_driver.display_text(short_name)
        else:
            rainbow_driver.display_text("????")

def display_personality_info():
    """Display current personality info on display"""
    if rainbow_driver:
        if available_personalities and 0 <= selected_index < len(available_personalities):
            personality = available_personalities[selected_index]
            # Show emoji or first 4 chars
            emoji = personality.get('avatar_emoji', '')
            if emoji and len(emoji) <= 4:
                rainbow_driver.display_text(emoji)
            else:
                short_name = personality['name'][:4].upper()
                rainbow_driver.display_text(short_name)
        else:
            rainbow_driver.display_text("????")

def handle_model_selection():
    """Enter model selection mode"""
    global model_select_mode, selected_index
    
    if not available_models:
        print("[MODEL] No models available")
        return
    
    model_select_mode = True
    selected_index = 0
    
    # Find current model index
    if current_model:
        for i, model in enumerate(available_models):
            if model['name'] == current_model['name']:
                selected_index = i
                break
    
    update_animation_state(MODEL_SELECT)
    display_model_info()
    print(f"[MODEL] Entering model selection mode. Current: {current_model['name'] if current_model else 'None'}")
    
    # Play entering selection sound
    if buzzer_manager:
        buzzer_manager.play_tone_immediate(440, 0.1)  # A4 note

def handle_personality_selection():
    """Enter personality selection mode"""
    global personality_select_mode, selected_index
    
    if not available_personalities:
        print("[PERSONALITY] No personalities available")
        return
    
    personality_select_mode = True
    selected_index = 0
    
    # Find current personality index
    if current_personality:
        for i, p in enumerate(available_personalities):
            if p['name'] == current_personality['name']:
                selected_index = i
                break
    
    update_animation_state(PERSONALITY_SELECT)
    display_personality_info()
    print(f"[PERSONALITY] Entering selection mode. Current: {current_personality['name'] if current_personality else 'None'}")
    
    # Play entering selection sound
    if buzzer_manager:
        buzzer_manager.play_tone_immediate(523, 0.1)  # C5 note

def confirm_model_selection():
    """Confirm current model selection"""
    global model_select_mode, current_model
    
    if selected_index < len(available_models):
        current_model = available_models[selected_index]
        model_select_mode = False
        
        # Save config
        save_config()
        
        print(f"[MODEL] Selected: {current_model['name']}")
        
        # Get model info for announcement
        model_info = f"Model changed to {current_model['name']}"
        if 'parameters' in current_model:
            model_info += f", {current_model['parameters']} parameters"
        
        # Announce selection
        tts_file = get_tts_audio(model_info)
        if tts_file:
            play_audio(tts_file)
        
        # Play success sound
        if buzzer_manager:
            buzzer_manager.play_sequence_async([440, 554, 659], [0.1, 0.1, 0.2])
        
        update_animation_state(IDLE)

def confirm_personality_selection():
    """Confirm current personality selection"""
    global personality_select_mode, current_personality
    
    if selected_index < len(available_personalities):
        new_personality = available_personalities[selected_index]
        
        # Switch on API side first
        if switch_personality_api(new_personality['name']):
            current_personality = new_personality
            personality_select_mode = False
            
            # Save config
            save_config()
            
            print(f"[PERSONALITY] Selected: {current_personality['name']} (voice: {current_personality['voice_id']})")
            
            # Get intro message from API response
            try:
                response = requests.get(ENDPOINTS['personality_current'])
                if response.ok:
                    data = response.json()
                    intro_msg = new_personality.get('intro_message', f"Switched to {new_personality['name']}")
                else:
                    intro_msg = f"Now I am {new_personality['name']}"
            except:
                intro_msg = f"Personality changed to {new_personality['name']}"
            
            # Announce with new voice
            tts_file = get_tts_audio(intro_msg)
            if tts_file:
                play_audio(tts_file)
            
            # Play success sound
            if buzzer_manager:
                buzzer_manager.play_sequence_async([523, 659, 784], [0.1, 0.1, 0.2])
        
        update_animation_state(IDLE)

def handle_button_press(button):
    """Handle button press events"""
    global model_select_mode, personality_select_mode, selected_index
    
    # Different behavior based on current mode
    if model_select_mode:
        if button == 'A':
            # Previous model
            selected_index = (selected_index - 1) % len(available_models)
            display_model_info()
            # Play navigation sound
            if buzzer_manager:
                buzzer_manager.play_tone_immediate(392, 0.05)  # G4
        elif button == 'B':
            # Confirm selection
            confirm_model_selection()
        elif button == 'C':
            # Next model
            selected_index = (selected_index + 1) % len(available_models)
            display_model_info()
            # Play navigation sound
            if buzzer_manager:
                buzzer_manager.play_tone_immediate(440, 0.05)  # A4
        return None
    
    elif personality_select_mode:
        if button == 'A':
            # Previous personality
            selected_index = (selected_index - 1) % len(available_personalities)
            display_personality_info()
            # Play navigation sound
            if buzzer_manager:
                buzzer_manager.play_tone_immediate(587, 0.05)  # D5
        elif button == 'B':
            # Confirm selection
            confirm_personality_selection()
        elif button == 'C':
            # Next personality
            selected_index = (selected_index + 1) % len(available_personalities)
            display_personality_info()
            # Play navigation sound
            if buzzer_manager:
                buzzer_manager.play_tone_immediate(659, 0.05)  # E5
        return None
    
    else:
        # Normal mode
        if button == 'A':
            # Enter model selection
            handle_model_selection()
        elif button == 'B':
            # Start recording
            # Play confirmation sound
            if buzzer_manager:
                buzzer_manager.play_tone_immediate(523, 0.1)  # C5
                time.sleep(0.1)
                buzzer_manager.play_tone_immediate(523, 0.1)  # C5 again
            return 'start_recording'
        elif button == 'C':
            # Enter personality selection
            handle_personality_selection()
    
    return None

# Include the rest of the functions from RoverOS_vCub.py...
# (find_headset_path, initialize_headset, verify_recording, etc.)

def find_headset_path():
    """Find the correct event device path for the headset"""
    try:
        for event_file in os.listdir('/dev/input/by-id'):
            if 'usb-Walmart_AB13X_Headset_Adapter' in event_file:
                return os.path.join('/dev/input/by-id', event_file)
        return '/dev/input/event0'
    except Exception as e:
        print(f"[ERROR] Error finding headset path: {e}")
        return '/dev/input/event0'

def initialize_headset():
    """Initialize the headset device"""
    try:
        EVENT_PATH = find_headset_path()
        dev = InputDevice(EVENT_PATH)
        print(f"[MIC] Found headset at {dev.path}")
        return dev
    except Exception as e:
        print(f"[ERROR] Could not initialize headset: {e}")
        return None

def verify_recording(file_path, min_size_kb=5):
    """Verify that the recording file exists and has reasonable size"""
    if not os.path.exists(file_path):
        print("[ERROR] Recording file not found")
        return False
    
    size_kb = os.path.getsize(file_path) / 1024
    print(f"[INFO] Recording file size: {size_kb:.1f}KB")
    
    if size_kb < min_size_kb:
        print(f"[ERROR] Recording file too small ({size_kb:.1f}KB < {min_size_kb}KB)")
        return False
    
    return True

def safe_terminate_process(proc):
    """Safely terminate a process"""
    if proc:
        try:
            proc.terminate()
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except:
                pass
        except:
            pass

def play_countdown_sounds():
    """Play countdown beeps for recording"""
    if buzzer_manager:
        for i in range(3):
            buzzer_manager.play_tone_immediate(440, 0.1)
            time.sleep(0.9)
        # Final longer beep
        buzzer_manager.play_tone_immediate(523, 0.3)

def start_recording(duration=10):
    """Start the recording process with visual countdown"""
    print(f"[REC] Starting {duration} second recording...")
    
    # Update display for countdown
    countdown_thread = None
    if rainbow_driver:
        def countdown_display():
            for i in range(duration, 0, -1):
                if rainbow_driver:
                    rainbow_driver.display_number(i)
                time.sleep(1)
        
        countdown_thread = threading.Thread(target=countdown_display)
        countdown_thread.start()
    
    # Play countdown sounds in parallel
    sound_thread = threading.Thread(target=play_countdown_sounds)
    sound_thread.start()
    
    return countdown_thread

def parse_args():
    parser = argparse.ArgumentParser(description='RoverCub with Personality System')
    parser.add_argument('--test', action='store_true', help='Run audio test')
    parser.add_argument('--text', action='store_true', help='Use text input instead of voice')
    parser.add_argument('--device', default='plughw:1,0', help='ALSA device')
    parser.add_argument('--rate', type=int, default=48000, help='Sample rate')
    parser.add_argument('--period', type=int, default=6000, help='Period size')
    return parser.parse_args()

def main():
    global rainbow_driver, buzzer_manager, led_animation_thread, led_animation_running
    global selected_index
    
    args = parse_args()
    
    # Fetch models and personalities from API
    if not fetch_models():
        print("[ERROR] Failed to initialize models")
        return
    
    if not fetch_personalities():
        print("[WARNING] Using default personalities")
    
    # Load configuration
    load_config()
    
    # Initialize Rainbow HAT
    try:
        if RainbowDriver and BuzzerManager:
            rainbow_driver = RainbowDriver(use_experimental_strip=False)
            buzzer_manager = BuzzerManager()
            print("[HAT] Rainbow HAT initialized")
            
            # Set up button handlers
            def button_a_handler():
                handle_button_press('A')
            
            def button_b_handler():
                action = handle_button_press('B')
                if action == 'start_recording':
                    # Trigger recording in main thread
                    # Set a flag that main loop checks
                    rainbow_driver._trigger_recording = True
            
            def button_c_handler():
                handle_button_press('C')
            
            rainbow_driver.buttons['A'].when_pressed = button_a_handler
            rainbow_driver.buttons['B'].when_pressed = button_b_handler
            rainbow_driver.buttons['C'].when_pressed = button_c_handler
            
            # Add recording trigger flag
            rainbow_driver._trigger_recording = False
            
        else:
            print("[WARNING] Rainbow HAT drivers not available - running without HAT support")
            rainbow_driver = None
            buzzer_manager = None
            
    except Exception as e:
        print(f"[WARNING] Rainbow HAT initialization failed: {e}")
        rainbow_driver = None
        buzzer_manager = None
    
    # Start LED animation thread
    led_animation_running = True
    led_animation_thread = threading.Thread(target=led_animation_loop, daemon=True)
    led_animation_thread.start()
    
    # Initial state
    update_animation_state(SPECTRUM)
    print(f"[STATE] Changed to {SPECTRUM}")
    
    # Startup sound
    if buzzer_manager:
        buzzer_manager.play_sequence_async([262, 330, 392, 523], [0.1, 0.1, 0.1, 0.2])
    
    # Welcome message
    if rainbow_driver:
        if current_personality:
            personality_name = current_personality['name'][:8]
            rainbow_driver.scroll_text(f"HELLO {personality_name}")
        else:
            rainbow_driver.scroll_text("HELLO ROVER")
    
    time.sleep(2)
    update_animation_state(IDLE)
    print(f"[STATE] Changed to {IDLE}")
    
    if args.text:
        # Text mode
        print("\n[INFO] Running in text mode. Type your message and press Enter.")
        print("Commands:")
        print("  'quit' - Exit")
        print("  'clear' - Clear conversation history")
        print("  'model' - Enter model selection mode")
        print("  'personality' - Enter personality selection mode")
        print("  'refresh' - Refresh models and personalities from API")
        
        while True:
            try:
                prompt_name = f"{current_personality['name']}[{current_model['name'].split(':')[0]}]" if current_personality and current_model else "RoverCub"
                user_input = input(f"\n[{prompt_name}] Your message: ").strip()
                
                if user_input.lower() == 'quit':
                    break
                elif user_input.lower() == 'clear':
                    clear_conversation_history()
                    if rainbow_driver:
                        rainbow_driver.display_text("CLR")
                    continue
                elif user_input.lower() == 'model':
                    handle_model_selection()
                    # Simple text-based model selection
                    print("\nAvailable models:")
                    for i, model in enumerate(available_models):
                        marker = ">" if model == current_model else " "
                        print(f"{marker} {i+1}. {model['name']}")
                    try:
                        choice = int(input("Select model number: ")) - 1
                        if 0 <= choice < len(available_models):
                            selected_index = choice
                            confirm_model_selection()
                    except:
                        print("Invalid selection")
                    continue
                elif user_input.lower() == 'personality':
                    handle_personality_selection()
                    # Simple text-based personality selection
                    print("\nAvailable personalities:")
                    for i, p in enumerate(available_personalities):
                        marker = ">" if p == current_personality else " "
                        print(f"{marker} {i+1}. {p['avatar_emoji']} {p['name']} - {p['description']}")
                    try:
                        choice = int(input("Select personality number: ")) - 1
                        if 0 <= choice < len(available_personalities):
                            selected_index = choice
                            confirm_personality_selection()
                    except:
                        print("Invalid selection")
                    continue
                elif user_input.lower() == 'refresh':
                    print("[REFRESH] Refreshing models and personalities...")
                    fetch_models()
                    fetch_personalities()
                    continue
                
                print("\n[AI] Getting response...")
                update_animation_state(PROCESSING)
                
                # Get LLM response
                response = get_llm_response(user_input)
                if response:
                    print(f"\n[{current_personality['name']}]: {response}")
                    
                    # Get TTS audio
                    update_animation_state(TALKING)
                    tts_file = get_tts_audio(response)
                    if tts_file:
                        play_audio(tts_file)
                
                update_animation_state(IDLE)
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"[ERROR] Text mode error: {e}")
                update_animation_state(IDLE)
    
    else:
        # Voice mode - copy the voice mode code from RoverOS_vCub.py
        # ... (same voice mode implementation)
        pass
    
    # Cleanup
    print("\n[EXIT] Cleaning up...")
    led_animation_running = False
    if led_animation_thread:
        led_animation_thread.join(timeout=1)
    
    if rainbow_driver:
        rainbow_driver.shutdown()
    if buzzer_manager:
        buzzer_manager.shutdown()
    
    print("[DONE] Goodbye!")

if __name__ == "__main__":
    main() 