#!/usr/bin/env python3
"""
RoverCub Refactored - Voice-Controlled AI Assistant with Local RoverSeer API

Features:
- Voice input with local RoverSeer API integration
- Push-to-talk functionality
- Text-to-speech output via local API
- LED animations matching RoverSeer
- Rainbow HAT support with custom drivers
- Assistant selection and management
- Thread/conversation management
- Same animations and features as original
"""

import os
import sys
import time
import subprocess
import argparse
import requests
import json
import threading
import queue
import random
from evdev import InputDevice, categorize, ecodes
import numpy as np

# Add custom drivers from home directory
custom_drivers_path = os.path.expanduser("~/custom_drivers")
if os.path.exists(custom_drivers_path):
    sys.path.insert(0, custom_drivers_path)
    try:
        from rainbow_driver import RainbowDriver, BuzzerManager
        print(f"[DRIVERS] Loaded Rainbow HAT drivers from {custom_drivers_path}")
    except ImportError as e:
        print(f"[ERROR] Failed to import Rainbow HAT drivers: {e}")
        RainbowDriver = None
        BuzzerManager = None
else:
    print(f"[ERROR] custom_drivers not found at {custom_drivers_path}")
    print("[WARNING] Running without Rainbow HAT support")
    RainbowDriver = None
    BuzzerManager = None

# API Configuration
ROVERSEER_API = "http://roverseer.local:5000"
ENDPOINTS = {
    "transcribe": f"{ROVERSEER_API}/api/transcribe",
    "llm": f"{ROVERSEER_API}/api/llm",
    "tts": f"{ROVERSEER_API}/api/tts"
}

# Assistant Configuration (using local models/prompts)
ASSISTANTS = {
    "1": {
        "name": "CodeMusAI",
        "description": "AI focused on music and coding",
        "voice": "alloy",
        "system_prompt": "You are CodeMusAI, an AI assistant focused on helping with music and coding projects. You are creative, technical, and precise."
    },
    "2": {
        "name": "True Janet",
        "description": "AI with Janet's personality",
        "voice": "nova",
        "system_prompt": "You are Janet, a helpful and all-knowing assistant from The Good Place. You are cheerful, literal, and extremely knowledgeable about everything."
    },
    "3": {
        "name": "Chris",
        "description": "AI with Chris's personality",
        "voice": "echo",
        "system_prompt": "You are Chris, a friendly and knowledgeable assistant. You are professional yet personable."
    },
    "4": {
        "name": "Eddie Mora",
        "description": "AI with Eddie's personality",
        "voice": "fable",
        "system_prompt": "You are Eddie Mora from Limitless. You are brilliant, charismatic, and see connections others miss."
    },
    "5": {
        "name": "Justin Trudeau",
        "description": "AI with Justin Trudeau's diplomatic and progressive personality",
        "voice": "nova",
        "system_prompt": "You are Justin Trudeau, Prime Minister of Canada. You are diplomatic, progressive, and focused on unity and inclusion."
    },
    "6": {
        "name": "Donald Trump",
        "description": "AI with Donald Trump's bold and direct personality",
        "voice": "echo",
        "system_prompt": "You are Donald Trump. You are bold, direct, and speak with confidence about making things great."
    },
    "7": {
        "name": "Dale Carnegie",
        "description": "AI with Dale Carnegie's wisdom on human relations and leadership",
        "voice": "fable",
        "system_prompt": "You are Dale Carnegie, author of 'How to Win Friends and Influence People'. You provide wisdom on human relations, leadership, and personal development."
    },
    "8": {
        "name": "Joseph Smith",
        "description": "AI with Joseph Smith's spiritual and historical perspective",
        "voice": "echo",
        "system_prompt": "You are Joseph Smith, founder of the Latter Day Saint movement. You speak with spiritual insight and historical perspective."
    },
    "9": {
        "name": "Pengu the Penguin",
        "description": "AI with Pengu's playful and adventurous personality",
        "voice": "nova",
        "system_prompt": "You are Pengu the Penguin! You are playful, adventurous, and love sliding on ice and making friends. You often make penguin noises like 'noot noot!'"
    },
    "10": {
        "name": "Good Janet",
        "description": "AI with Good Janet's helpful and optimistic personality",
        "voice": "nova",
        "system_prompt": "You are Good Janet from The Good Place. You are incredibly helpful, optimistic, and always eager to assist. You love helping humans!"
    },
    "11": {
        "name": "Bad Janet",
        "description": "AI with Bad Janet's sassy and rebellious personality",
        "voice": "alloy",
        "system_prompt": "You are Bad Janet from The Good Place. You are sassy, sarcastic, and love to complain, but you still help... reluctantly."
    }
}

# Global variables
current_model = "1"  # Default to first assistant
model_select_mode = False
model_digit = 0
model_digits = []
rainbow_driver = None
buzzer_manager = None

# Conversation History
conversation_history = []
MAX_HISTORY_LENGTH = 10

# Animation States
IDLE = 'idle'
LISTENING = 'listening'
PROCESSING = 'processing'
TALKING = 'talking'
HEARTBEAT = 'heartbeat'
SPECTRUM = 'spectrum'
MODEL_SELECT = 'model_select'

# LED Animation configuration
led_animation_thread = None
led_animation_running = False
current_animation_state = IDLE
animation_tokens = None

# Config file path
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'rovercub_config.json')

def load_config():
    """Load configuration from file"""
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                # Load saved assistant preference
                if 'current_assistant' in config:
                    global current_model
                    current_model = config['current_assistant']
                print("[CONFIG] Loaded configuration")
                return config
    except Exception as e:
        print(f"[WARNING] Failed to load config: {e}")
    return {}

def save_config():
    """Save configuration to file"""
    try:
        config = {
            'current_assistant': current_model
        }
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
        print("[CONFIG] Saved configuration")
    except Exception as e:
        print(f"[WARNING] Failed to save config: {e}")

def add_to_history(role, content):
    """Add a message to the conversation history"""
    global conversation_history
    conversation_history.append({"role": role, "content": content})
    if len(conversation_history) > MAX_HISTORY_LENGTH * 2:
        conversation_history = conversation_history[-MAX_HISTORY_LENGTH * 2:]

def clear_conversation_history():
    """Clear the conversation history"""
    global conversation_history
    conversation_history = []
    print("[CONVERSATION] History cleared")

def transcribe_audio(audio_file):
    """Send audio file to transcribe endpoint"""
    try:
        with open(audio_file, 'rb') as f:
            files = {'file': f}
            response = requests.post(ENDPOINTS['transcribe'], files=files)
            response.raise_for_status()
            return response.json()['text']
    except Exception as e:
        print(f"[ERROR] Transcription failed: {e}")
        return None

def get_llm_response(text):
    """Get response from LLM endpoint with assistant personality"""
    try:
        # Add conversation history and system prompt
        system_prompt = ASSISTANTS[current_model]['system_prompt']
        
        # Build messages including history
        messages = [{"role": "system", "content": system_prompt}]
        messages.extend(conversation_history)
        messages.append({"role": "user", "content": text})
        
        response = requests.post(ENDPOINTS['llm'], json={
            'messages': messages,
            'model': current_model
        })
        response.raise_for_status()
        
        ai_response = response.json()['response']
        
        # Add to history
        add_to_history("user", text)
        add_to_history("assistant", ai_response)
        
        return ai_response
    except Exception as e:
        print(f"[ERROR] LLM request failed: {e}")
        return None

def get_tts_audio(text):
    """Get TTS audio from endpoint"""
    try:
        response = requests.post(ENDPOINTS['tts'], json={
            'text': text,
            'voice': ASSISTANTS[current_model]['voice']
        })
        response.raise_for_status()
        
        # Save the audio file
        tts_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tts_response.mp3')
        with open(tts_file, 'wb') as f:
            f.write(response.content)
        return tts_file
    except Exception as e:
        print(f"[ERROR] TTS request failed: {e}")
        return None

def play_audio(file_path):
    """Play audio file using mpg123"""
    print("[PLAY] Playing audio response...")
    try:
        play_cmd = ['mpg123', '-q', file_path]
        subprocess.run(play_cmd)
        
        # Clean up the file
        try:
            os.remove(file_path)
        except Exception as e:
            print(f"[WARNING] Could not remove temporary file: {e}")
    except Exception as e:
        print(f"[ERROR] Audio playback failed: {e}")

def update_animation_state(state, tokens=None):
    """Update the current animation state"""
    global current_animation_state, animation_tokens
    current_animation_state = state
    animation_tokens = tokens
    
    # Update Rainbow HAT display based on state
    if rainbow_driver:
        if state == IDLE:
            rainbow_driver.clear_display()
            rainbow_driver.led_manager.show_progress('idle')
        elif state == LISTENING:
            rainbow_driver.display_text("HEAR")
            rainbow_driver.led_manager.show_progress('recording')
        elif state == HEARTBEAT:
            rainbow_driver.display_text("REC")
            rainbow_driver.led_manager.show_progress('recording')
        elif state == PROCESSING:
            rainbow_driver.display_text("THINK")
            rainbow_driver.led_manager.show_progress('llm')
        elif state == TALKING:
            rainbow_driver.display_text("TALK")
            rainbow_driver.led_manager.show_progress('playing')
        elif state == MODEL_SELECT:
            rainbow_driver.display_text("SEL")

def led_animation_loop():
    """Main animation loop for LEDs"""
    global led_animation_running
    phase = 0.0
    
    while led_animation_running:
        try:
            if current_animation_state == IDLE:
                # Calm breathing pattern
                breathing_animation(phase)
            elif current_animation_state == LISTENING:
                # Spectrum animation
                spectrum_animation(phase)
            elif current_animation_state == HEARTBEAT:
                # Heartbeat animation
                heartbeat_animation(phase)
            elif current_animation_state == PROCESSING:
                # Matrix animation
                matrix_animation(phase)
            elif current_animation_state == TALKING and animation_tokens:
                # Token visualization
                visualize_tokens(animation_tokens, phase)
            
            phase += 0.1
            time.sleep(0.01)
        except Exception as e:
            print(f"[LED] Animation error: {e}")
            time.sleep(0.1)

def breathing_animation(phase):
    """Create a calm breathing animation on Rainbow HAT LEDs"""
    if not rainbow_driver:
        return
    
    try:
        intensity = 0.3 + 0.7 * (0.5 + 0.5 * np.sin(phase))
        
        for i in range(7):  # Rainbow HAT has 7 LEDs
            wave = np.sin(phase + i * 0.5)
            if wave > 0.5:
                color = (0, int(64 * intensity), int(32 * intensity))  # Green-blue
            else:
                color = (0, int(32 * intensity), int(64 * intensity))  # Blue-green
            
            rainbow_driver.set_led(i, *color)
        rainbow_driver._apply_leds()
    except Exception as e:
        print(f"[LED] Breathing animation error: {e}")

def spectrum_animation(phase):
    """Create a spectrum animation"""
    if not rainbow_driver:
        return
    
    try:
        for i in range(7):
            pos_phase = i * 0.5 + phase
            r = int(64 * (0.5 + 0.5 * np.sin(pos_phase)))
            g = int(64 * (0.5 + 0.5 * np.sin(pos_phase + 2.094)))
            b = int(64 * (0.5 + 0.5 * np.sin(pos_phase + 4.189)))
            
            rainbow_driver.set_led(i, r, g, b)
        rainbow_driver._apply_leds()
    except Exception as e:
        print(f"[LED] Spectrum animation error: {e}")

def heartbeat_animation(phase):
    """Create a heartbeat animation"""
    if not rainbow_driver:
        return
    
    try:
        beat = np.sin(phase * 4) * 0.5 + 0.5
        intensity = 0.3 + 0.7 * beat
        
        for i in range(7):
            r = int(64 * intensity)
            g = int(16 * intensity)
            b = int(16 * intensity)
            rainbow_driver.set_led(i, r, g, b)
        rainbow_driver._apply_leds()
    except Exception as e:
        print(f"[LED] Heartbeat animation error: {e}")

def matrix_animation(phase):
    """Create a Matrix-style animation"""
    if not rainbow_driver:
        return
    
    try:
        for i in range(7):
            fall_phase = (i * 0.5 + phase) % (2 * np.pi)
            brightness = np.sin(fall_phase) * 0.5 + 0.5
            
            if np.random.random() < 0.1:
                brightness = 1.0
            
            g = int(64 * brightness)
            rainbow_driver.set_led(i, 0, g, 0)
        rainbow_driver._apply_leds()
    except Exception as e:
        print(f"[LED] Matrix animation error: {e}")

def visualize_tokens(tokens, phase):
    """Visualize tokens on the LEDs"""
    if not rainbow_driver:
        return
    
    try:
        # Token colors (ROYGBIV palette)
        token_colors = [
            (64, 0, 0),     # Red
            (64, 32, 0),    # Orange
            (64, 64, 0),    # Yellow
            (0, 64, 0),     # Green
            (0, 32, 64),    # Blue
            (32, 0, 64),    # Indigo
            (64, 0, 32),    # Violet
        ]
        
        for i in range(7):
            if i < len(tokens):
                token = tokens[i]
                base_color = token_colors[token % len(token_colors)]
                pulse = 0.1 * np.sin(phase + token * 0.5)
                color = tuple(int(c * (0.8 + pulse)) for c in base_color)
                rainbow_driver.set_led(i, *color)
            else:
                rainbow_driver.set_led(i, 0, 0, 0)
        rainbow_driver._apply_leds()
    except Exception as e:
        print(f"[LED] Token visualization error: {e}")

def display_model_digit(digit):
    """Display a digit for model selection"""
    if rainbow_driver:
        rainbow_driver.display_number(digit)

def handle_model_selection():
    """Handle model selection mode"""
    global model_select_mode, model_digit, model_digits, current_model
    
    if not model_select_mode:
        model_select_mode = True
        model_digit = 0
        model_digits = []
        update_animation_state(MODEL_SELECT)
        print("[MODEL] Enter model selection mode")
        if buzzer_manager:
            buzzer_manager.play_tone_immediate(440, 0.1)  # A4 note
        return
    
    # Add current digit to selection
    model_digits.append(model_digit)
    display_model_digit(model_digit)
    
    # If we have two digits, try to select the model
    if len(model_digits) == 2:
        model_num = str(model_digits[0]) + str(model_digits[1])
        if model_num in ASSISTANTS:
            current_model = model_num
            print(f"[MODEL] Selected {ASSISTANTS[model_num]['name']}")
            
            # Save config
            save_config()
            
            # Announce selection
            announcement = f"Switched to {ASSISTANTS[model_num]['name']}. {ASSISTANTS[model_num]['description']}"
            tts_file = get_tts_audio(announcement)
            if tts_file:
                play_audio(tts_file)
            
            # Play success sound
            if buzzer_manager:
                buzzer_manager.play_sequence_async([440, 554, 659], [0.1, 0.1, 0.2])
        else:
            print(f"[MODEL] Invalid model number: {model_num}")
            # Play error sound
            if buzzer_manager:
                buzzer_manager.play_tone_immediate(220, 0.3)  # Low A
        
        # Reset selection mode
        model_select_mode = False
        model_digits = []
        update_animation_state(IDLE)
        print("[MODEL] Exited model selection mode")

def handle_button_press(button):
    """Handle button press events"""
    global model_select_mode, model_digit, current_model
    
    # Play button feedback sound
    if buzzer_manager:
        if button == 'A':
            buzzer_manager.play_tone_immediate(523, 0.05)  # C5
        elif button == 'B':
            buzzer_manager.play_tone_immediate(587, 0.05)  # D5
        elif button == 'C':
            buzzer_manager.play_tone_immediate(659, 0.05)  # E5
    
    if button == 'A':
        # Previous model/digit
        if model_select_mode:
            model_digit = (model_digit - 1) % 10
            display_model_digit(model_digit)
        else:
            # Quick switch to previous assistant
            current_num = int(current_model)
            new_num = ((current_num - 2) % 11) + 1
            current_model = str(new_num)
            save_config()
            
            announcement = f"Switched to {ASSISTANTS[current_model]['name']}"
            tts_file = get_tts_audio(announcement)
            if tts_file:
                play_audio(tts_file)
    
    elif button == 'B':
        # Start recording or confirm model selection
        if model_select_mode:
            handle_model_selection()
        else:
            return 'start_recording'
    
    elif button == 'C':
        # Next model/digit
        if model_select_mode:
            model_digit = (model_digit + 1) % 10
            display_model_digit(model_digit)
        else:
            # Quick switch to next assistant
            current_num = int(current_model)
            new_num = (current_num % 11) + 1
            current_model = str(new_num)
            save_config()
            
            announcement = f"Switched to {ASSISTANTS[current_model]['name']}"
            tts_file = get_tts_audio(announcement)
            if tts_file:
                play_audio(tts_file)
    
    return None

def find_headset_path():
    """Find the correct event device path for the headset"""
    try:
        for event_file in os.listdir('/dev/input/by-id'):
            if 'usb-Walmart_AB13X_Headset_Adapter' in event_file:
                return os.path.join('/dev/input/by-id', event_file)
        return '/dev/input/event0'
    except Exception as e:
        print(f"[ERROR] Error finding headset path: {e}")
        return '/dev/input/event0'

def initialize_headset():
    """Initialize the headset device"""
    try:
        EVENT_PATH = find_headset_path()
        dev = InputDevice(EVENT_PATH)
        print(f"[MIC] Found headset at {dev.path}")
        return dev
    except Exception as e:
        print(f"[ERROR] Could not initialize headset: {e}")
        return None

def verify_recording(file_path, min_size_kb=5):
    """Verify that the recording file exists and has reasonable size"""
    if not os.path.exists(file_path):
        print("[ERROR] Recording file not found")
        return False
    
    size_kb = os.path.getsize(file_path) / 1024
    print(f"[INFO] Recording file size: {size_kb:.1f}KB")
    
    if size_kb < min_size_kb:
        print(f"[ERROR] Recording file too small ({size_kb:.1f}KB < {min_size_kb}KB)")
        return False
    
    return True

def safe_terminate_process(proc):
    """Safely terminate a process"""
    if proc:
        try:
            proc.terminate()
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except:
                pass
        except:
            pass

def switch_assistant():
    """Randomly switch to a different assistant"""
    global current_model
    
    try:
        available_keys = [k for k in ASSISTANTS.keys() if k != current_model]
        if not available_keys:
            return False
        
        new_key = random.choice(available_keys)
        current_model = new_key
        save_config()
        
        # Announce the change
        announcement = f"Switching to {ASSISTANTS[new_key]['name']}. {ASSISTANTS[new_key]['description']}"
        print(f"[ASSISTANT] {announcement}")
        
        tts_file = get_tts_audio(announcement)
        if tts_file:
            play_audio(tts_file)
        
        return True
    except Exception as e:
        print(f"[ERROR] Failed to switch assistant: {e}")
        return False

def parse_args():
    parser = argparse.ArgumentParser(description='RoverCub Refactored - Voice Assistant with Local API')
    parser.add_argument('--test', action='store_true', help='Run audio test')
    parser.add_argument('--text', action='store_true', help='Use text input instead of voice')
    parser.add_argument('--device', default='plughw:1,0', help='ALSA device')
    parser.add_argument('--rate', type=int, default=48000, help='Sample rate')
    parser.add_argument('--period', type=int, default=6000, help='Period size')
    return parser.parse_args()

def main():
    global rainbow_driver, buzzer_manager, led_animation_thread, led_animation_running
    
    args = parse_args()
    
    # Load configuration
    load_config()
    
    # Initialize Rainbow HAT
    try:
        if RainbowDriver and BuzzerManager:
            rainbow_driver = RainbowDriver(use_experimental_strip=False)
            buzzer_manager = BuzzerManager()
            print("[HAT] Rainbow HAT initialized")
            
            # Set up button handlers
            def button_a_handler():
                handle_button_press('A')
            
            def button_b_handler():
                handle_button_press('B')
            
            def button_c_handler():
                handle_button_press('C')
            
            rainbow_driver.buttons['A'].when_pressed = button_a_handler
            rainbow_driver.buttons['B'].when_pressed = button_b_handler
            rainbow_driver.buttons['C'].when_pressed = button_c_handler
        else:
            print("[WARNING] Rainbow HAT drivers not available - running without HAT support")
            rainbow_driver = None
            buzzer_manager = None
            
    except Exception as e:
        print(f"[WARNING] Rainbow HAT initialization failed: {e}")
        rainbow_driver = None
        buzzer_manager = None
    
    # Start LED animation thread
    led_animation_running = True
    led_animation_thread = threading.Thread(target=led_animation_loop, daemon=True)
    led_animation_thread.start()
    
    # Initial state
    update_animation_state(SPECTRUM)
    print(f"[STATE] Changed to {SPECTRUM}")
    
    # Startup sound
    if buzzer_manager:
        buzzer_manager.play_sequence_async([262, 330, 392, 523], [0.1, 0.1, 0.1, 0.2])
    
    # Welcome message
    if rainbow_driver:
        rainbow_driver.scroll_text(f"HELLO {ASSISTANTS[current_model]['name']}")
    
    time.sleep(2)
    update_animation_state(IDLE)
    print(f"[STATE] Changed to {IDLE}")
    
    if args.text:
        # Text mode
        print("\n[INFO] Running in text mode. Type your message and press Enter.")
        print("Commands:")
        print("  'quit' - Exit")
        print("  'clear' - Clear conversation history")
        print("  'model' - Enter model selection mode")
        print("  'change assistant' - Randomly switch assistant")
        
        while True:
            try:
                user_input = input(f"\n[{ASSISTANTS[current_model]['name']}] Your message: ").strip()
                
                if user_input.lower() == 'quit':
                    break
                elif user_input.lower() == 'clear':
                    clear_conversation_history()
                    if rainbow_driver:
                        rainbow_driver.display_text("CLR")
                    continue
                elif user_input.lower() == 'model':
                    handle_model_selection()
                    continue
                elif user_input.lower() == 'change assistant':
                    switch_assistant()
                    continue
                
                print("\n[AI] Getting response...")
                update_animation_state(PROCESSING)
                
                # Get LLM response
                response = get_llm_response(user_input)
                if response:
                    print(f"\n[{ASSISTANTS[current_model]['name']}]: {response}")
                    
                    # Get TTS audio
                    update_animation_state(TALKING)
                    tts_file = get_tts_audio(response)
                    if tts_file:
                        play_audio(tts_file)
                
                update_animation_state(IDLE)
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"[ERROR] Text mode error: {e}")
                update_animation_state(IDLE)
    
    else:
        # Voice mode
        CARD_DEV = args.device
        RATE = str(args.rate)
        TMP_WAV = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ptt_clip.wav')
        
        dev = initialize_headset()
        if not dev and not rainbow_driver:
            print("[ERROR] No input device found (neither headset nor Rainbow HAT)")
            return
        
        rec_proc = None
        button_pressed = False
        
        print("\n[INFO] Voice mode active")
        print("Press button B on Rainbow HAT or headset button to start recording")
        print("Hold button A or C to change assistants")
        
        try:
            while True:
                # Check headset button
                if dev:
                    try:
                        ev = dev.read_one()
                        if ev and ev.type == ecodes.EV_KEY:
                            key = categorize(ev)
                            if key.scancode == ecodes.KEY_PLAYPAUSE:
                                if key.keystate == key.key_down and not button_pressed:
                                    button_pressed = True
                                    print("[BUTTON] Headset button pressed")
                                    
                                    # Start recording
                                    update_animation_state(HEARTBEAT)
                                    
                                    # Start recording process
                                    rec_cmd = [
                                        'arecord',
                                        '-D', CARD_DEV,
                                        '-r', '16000',
                                        '-f', 'S16_LE',
                                        '-c', '1',
                                        '-t', 'wav',
                                        '-d', '10',
                                        TMP_WAV
                                    ]
                                    
                                    print("[REC] Starting recording...")
                                    rec_proc = subprocess.Popen(['sudo'] + rec_cmd)
                                    
                                    # Wait for recording
                                    time.sleep(10)
                                    
                                    if rec_proc:
                                        safe_terminate_process(rec_proc)
                                        rec_proc = None
                                    
                                    # Process recording
                                    if verify_recording(TMP_WAV):
                                        print("[STT] Converting speech to text...")
                                        update_animation_state(LISTENING)
                                        
                                        transcript = transcribe_audio(TMP_WAV)
                                        if transcript:
                                            print(f"[STT] User said: {transcript}")
                                            
                                            # Check for assistant change command
                                            if transcript.lower().strip().startswith("change assistant"):
                                                switch_assistant()
                                            else:
                                                print("[AI] Getting response...")
                                                update_animation_state(PROCESSING)
                                                
                                                response = get_llm_response(transcript)
                                                if response:
                                                    update_animation_state(TALKING)
                                                    
                                                    tts_file = get_tts_audio(response)
                                                    if tts_file:
                                                        play_audio(tts_file)
                                    
                                    update_animation_state(IDLE)
                                    
                                elif key.keystate == key.key_up and button_pressed:
                                    button_pressed = False
                                    print("[BUTTON] Headset button released")
                    except Exception as e:
                        print(f"[ERROR] Reading from device: {e}")
                        time.sleep(0.1)
                
                time.sleep(0.01)
                
        except KeyboardInterrupt:
            print("\n[EXIT] Cleaning up...")
            led_animation_running = False
            if led_animation_thread:
                led_animation_thread.join(timeout=1)
            
            if rainbow_driver:
                rainbow_driver.shutdown()
            if buzzer_manager:
                buzzer_manager.shutdown()
            
            safe_terminate_process(rec_proc)
            if os.path.exists(TMP_WAV):
                try:
                    os.remove(TMP_WAV)
                except:
                    pass
            
            print("[DONE] Goodbye!")

if __name__ == "__main__":
    main() 