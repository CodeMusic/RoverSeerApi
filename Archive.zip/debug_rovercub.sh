#!/bin/bash

# Debug script for RoverCub issues

echo "🔍 RoverCub Debugging Script"
echo "=========================="

ROVERCUB_HOST="rovercub.local"
ROVERCUB_USER="codemusic"

# Check service status
echo -e "\n📊 Service Status:"
ssh "$ROVERCUB_USER@$ROVERCUB_HOST" "sudo systemctl status roveros.service --no-pager | head -15"

# Check recent logs
echo -e "\n📋 Recent Logs (last 50 lines):"
ssh "$ROVERCUB_USER@$ROVERCUB_HOST" "sudo journalctl -u roveros.service -n 50 --no-pager"

# Check if API is reachable from RoverCub
echo -e "\n🌐 Testing API connectivity from RoverCub:"
ssh "$ROVERCUB_USER@$ROVERCUB_HOST" "curl -s http://roverseer.local:5000/models | head -20"

# Check Python dependencies
echo -e "\n📦 Checking Python packages:"
ssh "$ROVERCUB_USER@$ROVERCUB_HOST" "python3 -c 'import requests; import numpy; from evdev import InputDevice; print(\"✅ All imports OK\")' 2>&1"

# Check if custom drivers are available
echo -e "\n🎩 Checking Rainbow HAT drivers:"
ssh "$ROVERCUB_USER@$ROVERCUB_HOST" "ls -la ~/custom_drivers/ | head -10"

# Test button events
echo -e "\n🔘 Checking button devices:"
ssh "$ROVERCUB_USER@$ROVERCUB_HOST" "ls -la /dev/input/by-id/ | grep -i 'headset\|button' || echo 'No headset found'"

echo -e "\n💡 To monitor live logs:"
echo "ssh $ROVERCUB_USER@$ROVERCUB_HOST 'sudo journalctl -u roveros.service -f'" 